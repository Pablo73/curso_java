package com.project.podcasts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PodcastsApplicationTests {

	@Test
	void contextLoads() {
	}

}
