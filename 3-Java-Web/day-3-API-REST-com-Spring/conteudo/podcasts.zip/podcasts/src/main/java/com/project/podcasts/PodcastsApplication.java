package com.project.podcasts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PodcastsApplication {

	public static void main(String[] args) {
		SpringApplication.run(PodcastsApplication.class, args);
	}

}
